STUD CODE / T BABI — BLACK LEATHER JACKET WEBSITE

Upload the extracted folder containing index.html, styles.css, and assets to Netlify.
The hero and product images show the black STUD CODE leather jacket without MOTION lettering.
The bag is a demo only; checkout is not connected to real payments yet.
